
__all__ = ['post_func']

def post_func(outputs):
    return outputs
