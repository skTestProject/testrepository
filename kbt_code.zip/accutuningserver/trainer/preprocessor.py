
'''This is auto-generated code. DO NOT EDIT THIS!!!'''

__all__ = ['prep_func']


def prep_func(inputs):
    return inputs

# from pyspark.sql import SparkSession
# from pyspark import SparkContext, SparkConf
# from pyspark.sql.types import *
# from pyspark.sql import functions as F
# from pyspark.sql.window import Window
# from pyspark.sql.functions import (
#     udf, col, lit, concat, last, avg, when, trim, ltrim, rtrim
# )
# from pyspark.ml.feature import *
# from pyspark.ml import *
# import json, csv, io, re, urllib

# from typing import Dict, List
# import os
# import pandas as pd
# from pyspark.sql.dataframe import DataFrame
# from pyspark.sql.functions import from_json, col


# __all__ = ['prep_func']


# base_path = os.path.relpath(os.path.dirname(__file__))

# conf = SparkConf().setAppName("pysparkApp")
# spark = SparkSession.builder.config(conf=conf).getOrCreate()
# sc = spark.sparkContext
# # sc.addFile("../pipeline/asset.py")
# sc.addFile(os.path.join(base_path, "../pipeline/asset.py"))

# from ..pipeline.asset import *


# customSchema = customSchema_yZik = StructType([StructField("CustomerId", IntegerType(), True), StructField("Surname", StringType(), True), StructField("CreditScore", IntegerType(), True), StructField("Geography", StringType(), True), StructField("Gender", StringType(), True), StructField("Age", IntegerType(), True), StructField("Tenure", IntegerType(), True), StructField("Balance", DoubleType(), True), StructField("NumOfProducts", IntegerType(), True), StructField("HasCrCard", IntegerType(), True), StructField("IsActiveMember", IntegerType(), True), StructField("EstimatedSalary", DoubleType(), True), StructField("Exited", IntegerType(), True)])
# df_schema = {'columns': ['CustomerId', 'Surname', 'CreditScore', 'Geography', 'Gender', 'Age', 'Tenure', 'Balance', 'NumOfProducts', 'HasCrCard', 'IsActiveMember', 'EstimatedSalary', 'Exited'], 'datatypes': ['int64', 'object', 'int64', 'object', 'object', 'int64', 'int64', 'float64', 'object', 'object', 'object', 'float64', 'object'], 'targetColumn': 'Exited'}
# pandas_schema = {c: t for c, t in zip(df_schema["columns"], df_schema["datatypes"])}


# def _df_from_json(json_str: str, schema=customSchema) -> DataFrame:
#     return spark.read.json(sc.parallelize([json_str]), schema=schema)


# def _df_from_dict(_dict: Dict, schema=customSchema) -> DataFrame:
#     return spark.createDataFrame([_dict], schema=schema)


# def _df_from_list(dict_list: List[Dict], schema=customSchema) -> DataFrame:
#     return spark.createDataFrame(dict_list, schema=schema)


# def _df_from_pandas_df(pandas_df: pd.DataFrame, schema=customSchema) -> DataFrame:
#     return spark.createDataFrame(pandas_df, schema=schema)

# def _is_valid_json(s: str) -> bool:
#   try:
#     json.loads(s)
#   except ValueError as e:
#     return False
#   return True


# def prep_func(inputs) -> pd.DataFrame:
#     if isinstance(inputs, str):
#         if _is_valid_json:
#             df = _df_from_json(inputs)
#         else:
#             raise ValueError(f'data in "instances": invalid json format')
#     elif isinstance(inputs, dict):
#         df = _df_from_dict(inputs)
#     elif isinstance(inputs, list):
#         df = _df_from_list(inputs)
#     elif isinstance(inputs, pd.DataFrame):
#         df = _df_from_pandas_df(inputs)
#     else:
#         raise ValueError(f'data in "instances": not supported format in [json, Dict, List[Dict], pd.DataFrame]')
    
#     df_yZik = df
#     # preprocessing start | df_yZik
#     # Wrangler
#     df_Sxh5 = df_yZik
    
#     # Wrangler - fillna
#     df_Sxh5 = df_yZik.fillna("Other", subset=["Geography"])
    
#     # Wrangler - fillna
#     df_Sxh5 = df_Sxh5.fillna(0, subset=["EstimatedSalary"])
    
#     # dataset
#     df_BsiM = df_Sxh5
    

#     prep = df_BsiM.toPandas()

#     return prep.astype(pandas_schema)

