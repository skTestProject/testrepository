import os
import sys
import json
import argparse
import pandas as pd
from typing import List, Tuple, Dict, Optional
from autologging import logged

flag_schema_start = "# schema start |"
flag_schema_end = "# schema end |"
flag_prep_start = "# preprocessing start |"
flag_prep_end = "# preprocessing end |"
flag_dataset = "# dataset"


parser = argparse.ArgumentParser()
parser.add_argument(
    '--prep_code',
    required=False,
    default=None,
    help='AIIP Pipeline Code.',
)
parser.add_argument(
    '--schema_json',
    required=False,
    default=os.path.join(
        os.path.dirname(os.path.realpath("__file__")),
        "columns.json",
    ),
    help='AIIP AutoML Schema.',
)


def get_index_and_content(
        code: List[str],
        flag=flag_schema_start
        ) -> Tuple[int, str]:
    _idx, _content = [
        (i, s.strip()) for i, s in enumerate(code) if s.startswith(flag)
    ][0]
    return _idx, _content


def get_schema_name(code) -> str:
    _, _code = get_index_and_content(code, flag=flag_schema_start)
    return _code.split(flag_schema_start)[-1].strip()


def get_source_dataset_name(code) -> str:
    _, _code = get_index_and_content(code, flag=flag_prep_start)
    return _code.split(flag_prep_start)[-1].strip()


def get_result_dataset_name(code) -> str:
    _, _code = get_index_and_content(code, flag=flag_prep_end)
    return _code.split(flag_prep_end)[-1].strip()


def get_schema_code(code) -> List[str]:
    _flag = get_schema_name(code)
    _, _content = get_index_and_content(code, flag=_flag)
    return _content


def get_prep_code(code) -> List[str]:
    _start_idx, _ = get_index_and_content(code, flag=flag_prep_start)
    _end_idx, _ = get_index_and_content(code, flag=flag_prep_end)
    return code[_start_idx:_end_idx]


@logged
def generate_pipeline_prep_code(df_schema: Dict, code: Optional[List[str]]):

    _indent = "    "

    if code:
        pipeline_schema_code = get_schema_code(code)
        pipeline_prep_code = _indent.join([s for s in get_prep_code(code)])
        src_dataset_name = get_source_dataset_name(code)
        res_dataset_name = get_result_dataset_name(code)
        prep_code = f"""'''This is auto-generated code. DO NOT EDIT THIS!!!'''


from pyspark.sql import SparkSession
from pyspark import SparkContext, SparkConf
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import (
    udf, col, lit, concat, last, avg, when, trim, ltrim, rtrim
)
from pyspark.ml.feature import *
from pyspark.ml import *
import json, csv, io, re, urllib

from typing import Dict, List
import os
import pandas as pd
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import from_json, col


__all__ = ['prep_func']


base_path = os.path.relpath(os.path.dirname(__file__))

conf = SparkConf().setAppName("pysparkApp")
spark = SparkSession.builder.config(conf=conf).getOrCreate()
sc = spark.sparkContext
# sc.addFile("../pipeline/asset.py")
sc.addFile(os.path.join(base_path, "../pipeline/asset.py"))

from ..pipeline.asset import *


customSchema = {pipeline_schema_code}
df_schema = {df_schema}
pandas_schema = {{c: t for c, t in zip(df_schema["columns"], df_schema["datatypes"])}}


def _df_from_json(json_str: str, schema=customSchema) -> DataFrame:
    return spark.read.json(sc.parallelize([json_str]), schema=schema)


def _df_from_dict(_dict: Dict, schema=customSchema) -> DataFrame:
    return spark.createDataFrame([_dict], schema=schema)


def _df_from_list(dict_list: List[Dict], schema=customSchema) -> DataFrame:
    return spark.createDataFrame(dict_list, schema=schema)


def _df_from_pandas_df(pandas_df: pd.DataFrame, schema=customSchema) -> DataFrame:
    return spark.createDataFrame(pandas_df, schema=schema)

def _is_valid_json(s: str) -> bool:
    try:
        json.loads(s)
    except ValueError as e:
        return False
    return True


def prep_func(inputs) -> pd.DataFrame:
    if isinstance(inputs, str):
        if _is_valid_json:
            df = _df_from_json(inputs)
        else:
            raise ValueError(f'data in "instances": invalid json format')
    elif isinstance(inputs, dict):
        df = _df_from_dict(inputs)
    elif isinstance(inputs, list):
        df = _df_from_list(inputs)
    elif isinstance(inputs, pd.DataFrame):
        df = _df_from_pandas_df(inputs)
    else:
        raise ValueError(f'data in "instances": not supported format in [json, Dict, List[Dict], pd.DataFrame]')
    
    {src_dataset_name} = df
    {pipeline_prep_code}
    X_inputs = {res_dataset_name}.toPandas().astype(pandas_schema)

    return X_inputs[X_inputs.columns.drop(df_schema["targetColumn"])]

"""
    else:
        prep_code = f"""'''This is auto-generated code. DO NOT EDIT THIS!!!'''


import numpy as np
import pandas as pd


__all__ = ['prep_func']


df_schema = {df_schema}
pandas_schema = {{c: t for c, t in zip(df_schema["columns"], df_schema["datatypes"])}}

def prep_func(inputs):
    if 'labels' in inputs:
        X_inputs = pd.DataFrame(inputs['instances'], columns=inputs['labels']).astype(pandas_schema)
    elif 'columns' in inputs:
        X_inputs = pd.DataFrame(inputs['instances'], columns=inputs['columns']).astype(pandas_schema)
    else:
        X_inputs = pd.DataFrame(inputs['instances'], columns=df_schema['columns']).astype(pandas_schema)

    return X_inputs[X_inputs.columns.drop(df_schema["targetColumn"])]

"""

    file_dir = os.path.dirname(os.path.realpath("__file__"))
    module_prep_filepath = os.path.join(file_dir, "accutuningserver/trainer/preprocessor.py")
    with open(module_prep_filepath, "w") as f:
        f.write(prep_code)

    generate_pipeline_prep_code._log.info(
        f"pipeline preprocessing code is generated: {module_prep_filepath}"
    )


if __name__ == "__main__":

    args, _ = parser.parse_known_args()

    code = None
    if args.prep_code:
        if os.path.isfile(args.prep_code) and os.access(args.prep_code, os.R_OK):
            with open(args.prep_code, "r") as prep:
                code = prep.readlines()

    if os.path.isfile(args.schema_json) and os.access(args.schema_json, os.R_OK):
        with open(args.schema_json, "r") as f:
            df_schema = json.load(f)
        
        df_schema["datatypes"] = [d.lower() for d in df_schema["datatypes"]]
        generate_pipeline_prep_code(df_schema, code)
