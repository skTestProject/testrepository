#-- coding: utf-8 --
import sys
sys.path.insert(0, "/home/dpcore/.local/lib/python3.6/site-packages")

from pyspark.sql import SparkSession
from pyspark import SparkContext, SparkConf
from pyspark.sql.types import *
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import udf, col, lit, concat, last, avg, when, trim, ltrim, rtrim
from pyspark.ml.feature import *
from pyspark.ml import *
import json, csv, io, re, urllib

conf = SparkConf().setAppName("pysparkApp").set("spark.driver.cores", 1).set("spark.driver.memory", "1G").set("spark.executor.cores", 1).set("spark.executor.memory", "1G").set("spark.executor.instances", 3)
sqlContext = SparkSession.builder.config(conf=conf).enableHiveSupport().getOrCreate()
sc = sqlContext.sparkContext
sqlContext.sparkContext.addPyFile('asset.py')
from asset import *

# schema start | customSchema_yZik
# importLocal Custom Schema
customSchema_yZik = StructType([StructField("CustomerId", IntegerType(), True), StructField("Surname", StringType(), True), StructField("CreditScore", IntegerType(), True), StructField("Geography", StringType(), True), StructField("Gender", StringType(), True), StructField("Age", IntegerType(), True), StructField("Tenure", IntegerType(), True), StructField("Balance", DoubleType(), True), StructField("NumOfProducts", IntegerType(), True), StructField("HasCrCard", IntegerType(), True), StructField("IsActiveMember", IntegerType(), True), StructField("EstimatedSalary", DoubleType(), True), StructField("Exited", IntegerType(), True)])

# schema end | customSchema_yZik
# importLocal
df_yZik = sqlContext.read.option("delimiter", "").option("header", "true").csv(sc.textFile("/livy-files/upload/405/v2z5-XH82-J3Kn-PLK1-J2sv-976n-u115-M554/A-1) Bank_Churn_Modeling_min.csv").map(lambda line : "".join(line.split(","))), schema = customSchema_yZik)

# Activate Smart Parser
df_yZik = smartParser(df_yZik, "none", 0)

# preprocessing start | df_yZik
# Wrangler
df_Sxh5 = df_yZik

# Wrangler - fillna
df_Sxh5 = df_yZik.fillna("Other", subset=["Geography"])

# Wrangler - fillna
df_Sxh5 = df_Sxh5.fillna(0, subset=["EstimatedSalary"])

# dataset
df_BsiM = df_Sxh5

# preprocessing end | df_BsiM
sc.stop()